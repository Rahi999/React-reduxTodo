export const INCREMENT_COUNTER = "counter/increment";
export const DECREMENT_COUNTER = "counter/decrement";

export const ADD_TODO = "todo/add";
export const COMPLETE_TODO = "todo/complete";
export const UPDATE_TODO = "todo/update";
export const DELETE_TODO = "todo/delete";
